#import <Flutter/Flutter.h>

@interface GoogleMlKitFaceDetectionPlugin : NSObject<FlutterPlugin>
@end
