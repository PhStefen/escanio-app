## 0.8.0

* Fix: Pass `referenceTime` to native API when calling `annotateText`.
* Update dependencies.

## 0.7.0

* Update dependencies.

## 0.6.0

* Update dependencies.

## 0.5.0

* Update dependencies.

## 0.4.0

* Fix: EntityType enum order.

## 0.3.0

* Allow multiple instances in native layer.

## 0.2.1

* Update README and documentation.

## 0.2.0

* Fix: return after closing detector in iOS.

## 0.1.0

* Update documentation.

## 0.0.3

* Fix: Close detector.

## 0.0.2

* Fix: add `downloadModelIfNeeded`.
* Update documentation.

## 0.0.1

* Initial release.
