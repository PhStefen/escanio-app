#import <Flutter/Flutter.h>

@interface GoogleMlKitEntityExtractionPlugin : NSObject<FlutterPlugin>
@end
