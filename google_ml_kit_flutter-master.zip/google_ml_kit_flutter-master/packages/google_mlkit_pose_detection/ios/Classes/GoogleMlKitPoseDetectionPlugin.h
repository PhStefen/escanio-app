#import <Flutter/Flutter.h>

@interface GoogleMlKitPoseDetectionPlugin : NSObject<FlutterPlugin>
@end
