//
//  MlKitEnums.h
//  Pods
//
//  Created by Andrew Coutts on 7/13/22.
//

#ifndef MLKIT_FIREBASE_MODELS
    #define MLKIT_FIREBASE_MODELS 0
#endif
