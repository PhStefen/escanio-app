#import <Flutter/Flutter.h>

@interface GoogleMlKitImageLabelingPlugin : NSObject<FlutterPlugin>
@end
