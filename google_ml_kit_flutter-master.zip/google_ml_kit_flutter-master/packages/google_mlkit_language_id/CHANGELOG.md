## 0.7.0

* Fix: Pass `id` to native API when calling `identifyLanguage`.
* Update dependencies.

## 0.6.0

* Update dependencies.

## 0.5.0

* Update dependencies.

## 0.4.0

* Update dependencies.

## 0.3.0

* Allow multiple instances in native layer.

## 0.2.0

* Fix: return after closing detector in iOS.

## 0.1.0

* Update documentation.

## 0.0.2

* Fix: Close detector.
* Update documentation.

## 0.0.1

* Initial release.
