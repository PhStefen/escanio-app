#import <Flutter/Flutter.h>

@interface GoogleMlKitLanguageIdPlugin : NSObject<FlutterPlugin>
@end
