## 0.8.0

* Update dependencies.

## 0.7.0

* Update dependencies.

## 0.6.0

* Update dependencies.

## 0.5.0

* Update dependencies.

## 0.4.0

* Add `DigitalInkRecognitionContext`.
* Add `WritingArea`.
* Update README.

## 0.3.0

* Allow multiple instances in native layer.
* Update README.

## 0.2.1

* Update `DigitalInkRecognizer` constructor.
* Update README.

## 0.2.0

* Fix: return after closing detector in iOS.
* Allow multiple strokes.

## 0.1.0

* Update documentation.

## 0.0.2

* Fix: Close detector.
* Update documentation.

## 0.0.1+1

* Update readme and example.

## 0.0.1

* Initial release.
