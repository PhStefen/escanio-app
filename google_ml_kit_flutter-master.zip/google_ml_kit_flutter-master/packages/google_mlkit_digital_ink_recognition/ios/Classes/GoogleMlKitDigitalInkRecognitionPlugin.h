#import <Flutter/Flutter.h>

@interface GoogleMlKitDigitalInkRecognitionPlugin : NSObject<FlutterPlugin>
@end
