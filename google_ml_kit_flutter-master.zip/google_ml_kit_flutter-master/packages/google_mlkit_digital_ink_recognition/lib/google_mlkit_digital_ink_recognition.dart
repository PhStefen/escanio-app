export 'package:google_mlkit_commons/google_mlkit_commons.dart';

export 'src/digital_ink_recognizer.dart';
