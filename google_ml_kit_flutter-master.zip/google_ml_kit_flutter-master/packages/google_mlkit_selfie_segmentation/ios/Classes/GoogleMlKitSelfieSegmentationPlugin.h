#import <Flutter/Flutter.h>

@interface GoogleMlKitSelfieSegmentationPlugin : NSObject<FlutterPlugin>
@end
