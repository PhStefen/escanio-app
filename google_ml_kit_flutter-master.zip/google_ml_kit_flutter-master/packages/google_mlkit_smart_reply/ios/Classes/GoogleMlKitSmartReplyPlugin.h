#import <Flutter/Flutter.h>

@interface GoogleMlKitSmartReplyPlugin : NSObject<FlutterPlugin>
@end
