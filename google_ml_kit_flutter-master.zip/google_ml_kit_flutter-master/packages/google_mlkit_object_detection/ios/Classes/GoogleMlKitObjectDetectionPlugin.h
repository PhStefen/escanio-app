#import <Flutter/Flutter.h>

@interface GoogleMlKitObjectDetectionPlugin : NSObject<FlutterPlugin>
@end
