#import <Flutter/Flutter.h>

@interface GoogleMlKitTextRecognitionPlugin : NSObject<FlutterPlugin>
@end
