## 0.8.1

* Fix: Confidence and angle only available for Android.
* Feat: Add `TextSymbol`, only available for Android.

## 0.7.0

* Fix: Add confidence and angle in object response for `TextLine` and `TextElement`.
* Update dependencies.

## 0.6.0

* Update dependencies.

## 0.5.0

* Update dependencies.

## 0.4.0

* Update dependencies.

## 0.3.0

* Allow multiple instances in native layer.

## 0.2.0

* Fix: return after closing detector in iOS.

## 0.1.0

* Update documentation.

## 0.0.2

* Fix: Close detector.
* Update documentation.

## 0.0.1

* Initial release.
