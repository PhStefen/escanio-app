#import <Flutter/Flutter.h>

@interface GoogleMlKitTranslationPlugin : NSObject<FlutterPlugin>
@end
