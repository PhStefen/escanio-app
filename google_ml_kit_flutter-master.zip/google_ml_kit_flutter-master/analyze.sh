#!/bin/bash

flutter format --set-exit-if-changed .
flutter analyze .
